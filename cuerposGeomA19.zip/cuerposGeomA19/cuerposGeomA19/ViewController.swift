//
//  ViewController.swift
//  cuerposGeomA19
//
//  Created by Yolanda Martinez on 8/25/19.
//  Copyright © 2019 com.itesm. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imgFigureHome: UIImageView!
    @IBOutlet weak var lbFHome: UILabel!
    @IBOutlet weak var lbSHome: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func unwindEsfera(unwindSegue: UIStoryboardSegue) {
        
    }
    
    @IBAction func unwindPrisma(unwindSegue: UIStoryboardSegue) {
        
    }

}

